/ * Programa C de Bubble Sort em ordem crescente e decrescente. * /
#include <stdio.h>

int main()
{
    int data[100],i,n,step,temp;
    printf("Digite o número de elementos que deseja ordenar: ");
    scanf("%d",&n);
    for(i=0;i<n;++i)
    {
        printf("%d. Insira o elemento aqui:",i+1);
        scanf("%d",&data[i]);
    }
    for(step=0;step<n-1;++step)
    for(i=0;i<n-step-1;++i)
    {
        if(data[i]>data[i+1])   /* Se você deseja classificar em ordem decrescente, altere> para <apenas aqui. */
        {
            temp=data[i];
            data[i]=data[i+1];
            data[i+1]=temp;
        }
    }
    printf("Em ordem crescente:");
    for(i=0;i<n;++i)
         printf("%d  ",data[i]);
    return 0;
}

/ * Programa C de Select Sort em ordem crescente e decrescente. * /

#include <stdio.h>

void selection_sort (int vetor[],int max) {
  int i, j, min, aux;
  
  for (i = 0; i < (max - 1); i++) {
    /* O minimo é o primeiro número não ordenado ainda */
    min = i;
    for (j = i+1; j < max; j++) {
      /* Caso tenha algum numero menor ele faz a troca do minimo*/
      if (vetor[j] < vetor[min]) {
   min = j;
      }
    }
    /* Se o minimo for diferente do primeiro numero não ordenado ele faz a troca para ordena-los*/
    if (i != min) {
      aux = vetor[i];
      vetor[i] = vetor[min];
      vetor[min] = aux;
    }
  }
  /* Imprime o vetor ordenado */
  for (i = 0; i < max; i++) {
    printf ("%d ",vetor[i]);
  }
  printf ("\n");
}

main () {
  int max, i;
  /* Lê o máximo de algarismos do vetor*/
  scanf ("%d",&max);
  
  int  vetor[max];
  /* Lê os algarismos do vetor */
  for (i = 0; i < max; i++) {
    scanf ("%d",&vetor[i]);
  }
  
  selection_sort (vetor, max);
  
}

/ * Programa C de Insertion Sort em ordem crescente e decrescente. * /

	#include 

	#define t 3

	struct Produto {

		int cod;
		float preco;

	};

	void lerVet( struct Produto *p ){

		int i;

		for ( i=0; icod);
			printf("\tPreco? ");
			scanf("%f",&p->preco);
			p++;

		}

	}

	void mostrarVet( struct Produto *p ){

		int i;

		for ( i=0; i < t; i++ ){

			printf("\tCodigo: %d\n",p->cod);
			printf("\tPreco.: %f\n\n",p->preco);
			p++;

		}

	}

	void trocar (struct Produto *pv, int x, int y) {

		struct Produto aux = pv[x];
		pv[x] = pv[y];
		pv[y] = aux; 

	}

	void bubbleSort( struct Produto *p){

		int i, j;

		for ( i=t-1; i > 0; i-- ){
			for ( j=0; j < i; j++ ){

				if ( p[j].cod > p[j+1].cod ) // A comparaÃ§Ã£o Ã© pelo membro cod da struct

					trocar(p, j, j+1);

			}
		

		}

	}

/ * Programa C de Heap Sort em ordem crescente e decrescente. * /

#include 
#include 

void lerVet( int *p, int t ){

	int i;

	for ( i=0; i 0 ) {

          i--;
          t = a[i];

      }
      else {

          n--;
          if (n == 0)
             return;

          t = a[n];
          a[n] = a[0];

      }
     
      pai = i;
      filho = i*2 + 1;
 
      while (filho < n) {

          if (( filho + 1 < n )  &&  ( a[filho + 1] > a[filho] ))
              filho++;

          if (a[filho] > t) {

             a[pai] = a[filho];
             pai = filho;
             filho = pai*2 + 1;

          }
          else
             break;

      }
      a[pai] = t;

   }
}

/ * Programa C de Merge Sort em ordem crescente e decrescente. * /

#include 

void lerVet( int *p, int t ){

	int i;

	for ( i=0; i 1 ) {

		meio = t / 2;
		mergeSort(p, meio);
		mergeSort(p + meio, t - meio);
		merge(p, t);

	}
}


void main(){

	int *p, tam;

	printf("Quantidade de elementos do vetor?");
	scanf("%d",&tam);

	p = (int*) malloc(tam * sizeof(int));
	
	printf("\nDigite o conteudo do vetor:\n");
	lerVet(p, tam);

	printf("\nConteudo digitado para o vetor:\n");
	mostrarVet(p, tam);

	printf("\nOrdenando o vetor...\n");
	mergeSort(p, tam);

	printf("\nConteudo do vetor ja ordenado:\n");
	mostrarVet(p, tam);

	free(p);

}

/ * Programa C de Quick Sort em ordem crescente e decrescente. * /

#include 

void lerVet( int *p, int t ){

	int i;

	for ( i=0; i pivo )
			dir--; 

		if ( esq < dir )
			trocar(v,esq,dir);

	}

	v[inf] = v[dir];
	v[dir] = pivo ;
	return dir;
}

void quickSort( int *p, int inf, int sup ) {

	int posPivo; // posição do pivô

	if ( inf >= sup )
		return;

	posPivo= divide(p,inf,sup); 
	quickSort(p,inf,posPivo-1);
	quickSort(p,posPivo+1,sup); 

}